## 0.2.0 (2019-02-09)

* Require acorn >= 6.1.0

## 0.1.1 (2018-11-06)

* Adapt to changes in acorn 6.0.3

## 0.1.0 (2018-09-14)

Initial release
